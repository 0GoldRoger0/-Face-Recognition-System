import dropbox


class cloud_storage:
    def __init__(self,access_token):
        self.at = access_token

    def uploadFile(self,file_from,file_to):
        f = open(file_from,'rb')
        f = f.read()

        dbx = dropbox.Dropbox(self.at)

        if file_from!='' and file_to!='':
            dbx.files_upload(f,file_to)
            print("Your files has been uploaded successfully")
        else:
            print("Sorry we need both file location and storage location to proceed!")

def main():
    print("Welcome to cloud based dropbox service")
    print("")

    # at = input("Enter your access token !")
    # user = cloud_storage(at)
    # print("")

    while True:
        yn = input("Would you like to upload your files on dropbox ? (y/n): ").lower()
        print("")

        if yn == 'y':
            ff = input("Enter the file name you want to upload: ")
            ft = input("Enter the folder where you would like to upload your file on dropbox: ")
            ft = '/'+ft+'/'+ff

            print("")

            #user.uploadFile(ff,ft)
        elif yn=='n':
            print("Thanks for using !")
        else:
            print("Answer in y/n, not in any other character.")

        print("")

main()
        



# import os
# import shutil

# path = "C:/Users/Vedant Fuldeore/Downloads/FACE RECOGNITION BASED ATTENDANCE MONITORING SYSTEM (1)/FACE RECOGNITION BASED ATTENDANCE MONITORING SYSTEM/Attendance"
# list = os.listdir(path)

# print(list[11])

# original = ""
# shutil.copy(list[11],original)
# print(original)


# # target = "https://www.dropbox.com/scl/fo/4fll7hgmnxdtljttgaoui/h?dl=0&rlkey=c5qwrszqijlke0wsabvsrzsgg"
# # shutil.move(index_list,target)

