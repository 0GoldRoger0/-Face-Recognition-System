from  pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import os
import datetime
import time
gauth = GoogleAuth()
drive =GoogleDrive(gauth)
ts = time.time()
date = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
print(date)
floder ='1EfV_MCrcuFV3nAZXUJ8SjEVoCnzHNiOQ'

directory ='C:/Users/hp/Downloads/FACE RECOGNITION BASED ATTENDANCE MONITORING SYSTEM/Attendance'
for f in os.listdir(directory):
    filename= os.path.join(directory,f)
    exist ='Attendance_'+date +'.csv'
    if exist in f:
        file1 = drive.CreateFile({'parents': [{'id': floder}], 'title': f})
        file1.SetContentFile(filename)
        print(exist+ " "+ f)
        file1.Upload()

